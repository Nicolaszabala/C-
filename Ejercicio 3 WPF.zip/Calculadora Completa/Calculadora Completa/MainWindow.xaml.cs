﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculadora_Completa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        long numero1 = 0;
        long numero2 = 0;    
        string operacion = ""; 
        public MainWindow()
        {
            InitializeComponent();
        }


    

        private void Btn_1_Click_1(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 1;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero1 * 10) + 1;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_2_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 2;
                text_resultado.Text = numero2.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 2;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_3_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 3;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 3;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_4_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 4;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 4;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_5_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 5;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 5;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_6_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 6;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 6;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_7_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 7;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 7;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_8_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 8;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 8;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_9_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 9;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 9;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_0_Click(object sender, RoutedEventArgs e)
        {
            if (operacion == "")
            {
                numero1 = (numero1 * 10) + 0;
                text_resultado.Text = numero1.ToString();
            }
            else
            {

                numero2 = (numero2 * 10) + 0;
                text_resultado.Text = numero2.ToString();
            }
        }

        private void Btn_Sum_Click(object sender, RoutedEventArgs e)
        {
            operacion = "+";
            text_resultado.Text = 0.ToString();
           
        
        }


        private void Btn_Res_Click(object sender, RoutedEventArgs e)
        {
            text_resultado.Text = 0.ToString();
            operacion = "-";
        }

        private void Btn_Mul_Click(object sender, RoutedEventArgs e)
        {
            text_resultado.Text = 0.ToString();
            operacion = "*";
            
        }

        private void Btn_Div_Click(object sender, RoutedEventArgs e)
        {
            text_resultado.Text = 0.ToString();
            operacion = "/";
        }

        private void Btn_igual_Click(object sender, RoutedEventArgs e)
        {
            switch (operacion)
            {
                case "+":
                    text_resultado.Text = (numero1 + numero2).ToString();
                    break;
                case "-":
                    text_resultado.Text = (numero1 - numero2).ToString();
                    break;
                case "*":
                    text_resultado.Text = (numero1 * numero2).ToString();
                    break;
                case "/":
                    text_resultado.Text = (numero1 / numero2).ToString();
                    break;

            }
            numero1 = 0;
            numero2 = 0;
            operacion = "";
        }

        private void reset_Btn_Click_1(object sender, RoutedEventArgs e)
        {

            numero1 = 0;
            numero2 = 0;
            operacion = "";
            text_resultado.Text = "0";
        }
    }
}
     
