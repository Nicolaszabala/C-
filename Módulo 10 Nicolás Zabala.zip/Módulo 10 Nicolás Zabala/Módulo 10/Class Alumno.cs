﻿
using System;

public class Alumno
{
    private string nombre;
    private string sexo;
    private string apellidos;
    private int nota;
    public Alumno()
    {
        this.nombre = "";
        this.apellidos = "";
        this.nota = 0;
        this.sexo = '';
    }
    public Alumno(string nom, string ape, int not, char sex)
    {
        this.nombre = nom;
        this.apellidos = ape;
        this.nota = not;
        this.sexo = sex;
    }

    public void IntroNombre(string nom)
    {
        nombre = nom;
    }

    public string DevuelveNombre()
    {
        return nombre;
    }
    public void IntroApellidos(string ape)
    {
        apellidos = ape;
    }

    public string DevuelveApellidos()
    {
        return apellidos;
    }

    public void Introsexo(char sex)
    {
        sexo = sex;
    }

    public string DevuelveSexo()
    {
        return sexo;
    }

    public void IntroNota(int not)
    {
        nota = not;
    }

    public int DevuelveNota()
    {

        return nota;

    }


    public override string ToString()
    {
        return apellidos + "," + nombre + "," + nota + " " + sexo + " " ;

        
    }
}
