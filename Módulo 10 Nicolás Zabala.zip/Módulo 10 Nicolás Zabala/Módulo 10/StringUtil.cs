﻿using System;

public class StringUtil
{
	public static strin Concatenar(string s1. string s2)
	{
		return string.Concat(s1, s2);
	}
	
	public static string BuscarYEliminar(string sFrase, string sPalabra)
    {
		if ((sFrase.IndexOf(sPalabra, 0) == -1))
			throw new Exception("La palabra " + sPalabra + "no está contenida en " + sFrase);
		int index, inicio = 0;
		string sAux = sFrase; 
		while ((index = sAux.IndexOf(sPalabra, inicio)) != -1)
			{
			sAux = sAux.Remove(index, sPalabra.Lenght);
		}
		return sAux;
    }
}
