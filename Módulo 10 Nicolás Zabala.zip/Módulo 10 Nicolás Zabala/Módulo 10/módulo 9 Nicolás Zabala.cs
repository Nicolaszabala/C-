﻿
using Ejercicio4Módulo9NZ;
using System;

public class Alumno
{
    private string nombre;
    private char sexo;
    private string apellidos;
    private int edad;
    public int nota;
    private string v1;
    private string v2;
    private int v3;

    public Alumno()
    {
        this.nombre = "";
        this.apellidos = "";
        this.edad = 0;
        this.sexo = ' ';
    }
    public Alumno(string nom, string ape, char sex, int ed)
    {
        this.nombre = nom;
        this.apellidos = ape;
        this.edad = ed;
        this.sexo = sex;
    }

    public Alumno(string v1, string v2, int v3)
    {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
    }

    public void IntroNombre(string nom)
    {
        nombre = nom;
    }

    public string DevuelveNombre()
    {
        return nombre;
    }
    public void IntroApellidos(string ape)
    {
        apellidos = ape;
    }

    public string DevuelveApellidos()
    {
        return apellidos;
    }

    public void Introsexo(char sex)
    {
       sexo = sex;
    }

    public char DevuelveSexo()
    {
        return sexo;
    }

    public void IntroEdad(int ed)
    {
        edad = ed;
    }

    public int DevuelveEdad()
    {
        
        return edad;
    }

    public void IntroNota(int not)
    {
        nota = not;
    }

    public int DevuelveNota()
    {

        return nota;
    }
    public override string ToString()
    {
        return apellidos + "," + nombre + "," + sexo + " "  + edad + " " + "años" + nota;

      //  return base.ToString();
    }
    

}
