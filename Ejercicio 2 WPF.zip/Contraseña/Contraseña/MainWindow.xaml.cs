﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Contraseña
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int nIntentos = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (textBox.Text == "Alumno" && passwordBox.Password == "CIPSA")
            {
                Prompt_label.Content = "BIENVENIDO";
            }
            if (textBox.Text != "Alumno")
            {
                Prompt_label.Content = "USUARIO NO RECONOCIDO";
                nIntentos++;
            }
         
            if (passwordBox.Password != "CIPSA")
                {
                    Prompt_label.Content = "CONTRASEÑA INCORRECTA";
                } 
            if( nIntentos >= 3)
            {
                Prompt_label.Content = "HA ALCANZADO EL NÚMERO MÁXIMO DE INTENTOS.PRESIONE ENTER";
                Close();

            }
   

        }  
        }
    }

