﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace Ejercicio4Módulo9NZ
{
    internal class Program
    {
        static void Main()
        {

         /*   Alumno alumno1 = new Alumno();
            Console.WriteLine("Introduce el nombre del alumno: ");
            alumno1.IntroNombre(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("El Nombre del alumno es: "+ alumno1.DevuelveNombre());
            Console.WriteLine("Introduce los Apellidos del alumno: ");
            alumno1.IntroApellidos(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Los Apellidos del alumno son: " + alumno1.DevuelveApellidos());
            Console.WriteLine("Introduce la edad del alumno: ");

            alumno1.IntroEdad(int.Parse(Console.ReadLine()));
            Console.Clear();
            Console.WriteLine("La Edad del alumno es: " + alumno1.DevuelveEdad());

            Console.WriteLine("Introduce el sexo del alumno, colocando el caracter 'H' si es hombre o 'M' si es mujer: ");
         
            alumno1.Introsexo(char.Parse(Console.ReadLine()));
            Console.WriteLine("El sexo del alumno es: " + alumno1.DevuelveSexo());
            
          
        
                ArrayList asignaturas = new ArrayList();  
                asignaturas.Add(new Asignatura("Español", "HUMANIDADES"));
                asignaturas.Add(new Asignatura("Inglés", "HUMANIDADES"));
                asignaturas.Add(new Asignatura("Filosofía", "CIENCIAS SOCIALES"));
                asignaturas.Add(new Asignatura("Química", "CIENCIAS NATURALES"));
                asignaturas.Add(new Asignatura("Ed. Física, Convivencia y Paz", "ARTES,LÚDICAS Y DEPORTES"));
                asignaturas.Add(new Asignatura("Ética, valores y religiones del mundo", "ÉTICA, VALORES Y RELIGIÓN"));
                asignaturas.Add(new Asignatura("EMPRENDIMIENTO, INFORMÁTICA Y TECNOLOGÍA", "EMPRENDIMIENTO, INFORMÁTICA Y TECNOLOGÍA"));
                asignaturas.Add(new Asignatura("Científico tecnológico", "A DIMENSIÓN COGNITIVA"));
                asignaturas.Add(new Asignatura("Pensamiento prosocial", "DIMENSIÓN SOCIOEMOCIONAL"));
                asignaturas.Add(new Asignatura("Artes", "ARTES,LÚDICAS Y DEPORTES"));
            foreach (Asignatura a in asignaturas)
            {
                Console.WriteLine(a.ToString());
            }*/

            Alumno alumno1 = new Alumno("Juan", "Pérez", 'H');
            alumno1.IntroNota(10);
            Alumno alumno2 = new Alumno("Felipe","García",'H');
            alumno2.IntroNota(8); 
            Alumno alumno3 = new Alumno("Mariela", "Ramírez", 'H');
            alumno3.IntroNota(9);
            Alumno alumno4= new Alumno("Francisco", "González", 'M');
            alumno4.IntroNota(6);
            Alumno alumno5= new Alumno("Juana", "Peralta", 'M');
            alumno5.IntroNota(7);
            Alumno alumno6= new Alumno("Romina", "Castilla", 'M');
            alumno6.IntroNota(8);

            Aula miaula = new Aula();
            Aula miaula2 = new Aula();
            miaula.addStudent(alumno1);
            miaula.addStudent(alumno2);
            miaula.addStudent(alumno3);
            miaula2.addStudent(alumno4);
            miaula2.addStudent(alumno5);
            miaula2.addStudent(alumno6);
            miaula.calcularMedia();
            miaula.getNumHombres(); 
            miaula2.calcularMedia();
            miaula2.getNumHombres();
            Console.WriteLine("Miaula1: "+ miaula.ToString());
            Console.WriteLine("Miaula2: " + miaula2.ToString());  
            Console.ReadKey();
            Academia academia = new Academia();
            academia.addAula(miaula);
            academia.addAula(miaula2);
            Console.WriteLine("Listado de alumnos de la academia: " + academia.getMediaAulas());
            Console.WriteLine("Resumen sexo de estudiantes de la academia: " + academia.resumenSexoEstudiantes());
            Console.ReadKey();








        }
    }
}