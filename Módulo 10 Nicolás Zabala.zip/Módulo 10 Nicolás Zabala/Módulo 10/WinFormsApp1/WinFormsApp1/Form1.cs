namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       private void button1_Click()
        {


            StringUtil.BuscarYEliminar(textBox1.Text, textBox2.Text);
            
            
        }

        private void button2_Click()
        {
          StringUtil.Concatenar(textBox3.Text, textBox4.Text);
        }

    }
}