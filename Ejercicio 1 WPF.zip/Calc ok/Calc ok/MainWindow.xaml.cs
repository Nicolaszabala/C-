﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calc_ok
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void producto_btn_Click(object sender, RoutedEventArgs e)
        {
            int valor1 = int.Parse(textBox_PrimerValor.Text);
            int valor2 = int.Parse(textBox_SegundoValor.Text);
            int producto = valor1 * valor2;
            textBox_Resultado.Text = producto.ToString();
        }

        private void division_btn_Click(object sender, RoutedEventArgs e)
        {
            int valor1 = int.Parse(textBox_PrimerValor.Text);
            int valor2 = int.Parse(textBox_SegundoValor.Text);
            int division = valor1 / valor2;
            textBox_Resultado.Text = division.ToString();
        }

        private void suma_btn_Click(object sender, RoutedEventArgs e)
        {
            int valor1 = int.Parse(textBox_PrimerValor.Text);
            int valor2 = int.Parse(textBox_SegundoValor.Text);
            int suma = valor1 + valor2;
            textBox_Resultado.Text = suma.ToString();
        }

        private void resta_btn_Click(object sender, RoutedEventArgs e)
        {
            int valor1 = int.Parse(textBox_PrimerValor.Text);
            int valor2 = int.Parse(textBox_SegundoValor.Text);
            int resta = valor1 + valor2;
            textBox_Resultado.Text = resta.ToString();
        }
    }
}
